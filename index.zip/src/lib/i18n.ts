import i18n from "i18next"
import { initReactI18next } from "react-i18next"
import LanguageDetector from "i18next-browser-languagedetector"

// Importamos las traducciones directamente como objetos
const translationES = {
  app: {
    title: "Grupo Silvestre Ético",
    description: "Sistema de reporte de irregularidades éticas",
  },
  navigation: {
    home: "Inicio",
    next: "Siguiente",
    previous: "Anterior",
    submit: "Enviar reporte",
  },
  steps: {
    mainData: "Datos principales",
    additionalData: "Datos adicionales",
    contact: "Contacto",
    personalInfo: "Información personal",
    summary: "Resumen",
  },
  form: {
    required: "* Campo requerido",
    multipleSelection: "Puede seleccionar múltiples opciones",
  },
  question1: {
    label: "Seleccione el tipo de irregularidad que desea reportar",
    options: {
      conflictsOfInterest: "⚖️ Conflictos de interés",
      bribery: "💰 Sobornos o coimas",
      confidentialInfoLeak: "🔓 Fuga de información confidencial",
      resourceMisuse: "🏢 Mal uso de recursos",
      discrimination: "🚫 Discriminación/Acoso",
      documentDestruction: "📝 Destrucción de documentos",
      lawViolation: "⚖️ Incumplimiento de leyes",
      policyViolation: "📋 Incumplimiento de políticas",
      otherUnethical: "⚠️ Otras actividades no éticas",
    },
    specify: "Especificar",
  },
  question2: {
    label: "Identifique a las personas involucradas",
    add: "Agregar",
    person: "Involucrado",
    fields: {
      firstName: "Nombres",
      lastName: "Apellidos",
      relation: "Relación con el Grupo",
      specify: "Especificar (empresa / cargo / otro)",
    },
    options: {
      employee: "Empleado",
      supplier: "Proveedor",
      client: "Cliente",
      investor: "Inversionista",
      other: "Otro",
    },
  },
  question3: {
    label: "Indique en qué lugar sucedió el incidente",
    fields: {
      country: "País",
      state: "Estado / Provincia",
      city: "Ciudad",
      location: "Sede",
      specifyLocation: "Especificar sede",
    },
    options: {
      plantCajamarquilla: "Planta Cajamarquilla",
      officesMiraflores: "Oficinas Miraflores",
      peripheralWarehouse: "Almacén periférico",
      other: "Otro (especificar)",
    },
  },
  question4: {
    label: "Indique la fecha o período en el cual sucedió el incidente",
    selectDate: "Seleccione una fecha",
  },
  question5: {
    label: "Describa todos los detalles que ayuden a analizar y evaluar su irregularidad",
    placeholder:
      "Incluya información relevante como fechas, lugares, personas involucradas y descripción detallada de los hechos.",
    characters: "caracteres",
  },
  question6: {
    label: "¿Posee usted evidencia física o digital que pueda ayudar en la investigación?",
    options: {
      notPossible: "No me es posible proporcionar evidencias de ningún tipo",
      notHave: "No tengo evidencias, pero podría obtenerlas",
      bothTypes: "Tengo evidencia física y digital que me gustaría entregar",
      physical: "Tengo evidencia física que deseo entregar",
      digital: "Tengo evidencia digital que deseo entregar",
    },
    fields: {
      physicalDelivery: "Indique la forma en la que entregará la información física",
      digitalFiles: "Seleccione evidencias digitales (máx. 5 archivos, 20MB)",
      whereToObtain: "¿Dónde el Grupo podría obtener evidencia?",
      whereElse: "¿Dónde más se podría obtener evidencia?",
    },
    fileAttach: "Los archivos se adjuntarán al enviar el formulario.",
  },
  question17: {
    label: "¿Cuál de las siguientes opciones describe mejor su relación con el Grupo?",
    options: {
      employee: "Empleado",
      supplier: "Proveedor",
      client: "Cliente",
      exEmployee: "Ex Empleado",
      other: "Otro",
    },
    specify: "Especificar",
  },
  question18: {
    label: "¿Desea mantener su identidad en el anonimato?",
    options: {
      no: "No",
      yes: "Sí",
    },
    emailContact: "Proporcione una cuenta de correo electrónico para mantener contacto",
    emailNote: "Este correo se utilizará únicamente para comunicaciones relacionadas con su reporte.",
  },
  personalInfo: {
    title: "Información Opcional de Contacto",
    subtitle:
      "En caso de no tener inconveniente de compartir su identidad, por favor proporcione la siguiente información opcional",
    anonymous: "Ha elegido mantener su identidad en el anonimato. Puede continuar al siguiente paso.",
    fields: {
      fullName: "Indique sus nombres y apellidos",
      phone: "Indique un teléfono de contacto",
      email: "Indique un correo electrónico de contacto",
      otherContact: "Indique cualquier otra forma de contacto",
      position: "Indique el cargo que ocupa en el Grupo",
      area: "Indique el área a la cual pertenece",
    },
    areas: {
      hr: "RRHH",
      finance: "Finanzas",
      accounting: "Contabilidad",
      management: "Gerencia",
      other: "Otros",
    },
  },
  summary: {
    title: "Resumen del Reporte",
    reviewNote:
      "Por favor revise la información antes de enviar su reporte. Una vez enviado, recibirá un código de seguimiento.",
    sections: {
      mainData: "Datos Principales",
      mainDataDesc: "Información básica sobre la irregularidad",
      contactData: "Datos de Contacto",
      contactDataDesc: "Información para comunicarnos con usted",
    },
    fields: {
      irregularityTypes: "Tipos de irregularidad",
      date: "Fecha del incidente",
      location: "Ubicación",
      involvedPeople: "Personas involucradas",
      details: "Detalles",
      evidence: "Evidencia",
      whereToObtain: "Dónde obtener",
      relationWithGroup: "Relación con el Grupo",
      anonymousReport: "Reporte anónimo",
      contactEmail: "Correo de contacto",
      name: "Nombre",
      phone: "Teléfono",
      email: "Correo electrónico",
      position: "Cargo",
      area: "Área",
    },
    notSpecified: "No especificado",
    terms: {
      authorize: "Autorizo a Grupo Silvestre a realizar el tratamiento de mis datos personales",
      agreement: "Al enviar este formulario, acepto que he leído la cláusula de tratamiento de datos personales.",
    },
    submitNote:
      'Pulse el botón "Enviar reporte" para registrar su irregularidad. Recibirá un código de seguimiento para consultas futuras.',
  },
  success: {
    title: "Reporte enviado con éxito",
    message: "Será redirigido a la página principal en unos segundos...",
    code: "Su reporte ha sido registrado con el código: GS-",
  },
  errors: {
    incompleteFields: "Por favor complete todos los campos requeridos antes de continuar.",
    termsRequired: "Debe aceptar los términos y condiciones para enviar el reporte.",
    submitError: "Error al enviar el reporte",
    tryAgain: "Por favor, inténtelo de nuevo más tarde.",
  },
}

const translationEN = {
  app: {
    title: "Grupo Silvestre Ethics",
    description: "Ethical irregularities reporting system",
  },
  navigation: {
    home: "Home",
    next: "Next",
    previous: "Previous",
    submit: "Submit report",
  },
  steps: {
    mainData: "Main data",
    additionalData: "Additional data",
    contact: "Contact",
    personalInfo: "Personal information",
    summary: "Summary",
  },
  form: {
    required: "* Required field",
    multipleSelection: "You can select multiple options",
  },
  question1: {
    label: "Select the type of irregularity you want to report",
    options: {
      conflictsOfInterest: "⚖️ Conflicts of interest",
      bribery: "💰 Bribes or kickbacks",
      confidentialInfoLeak: "🔓 Confidential information leak",
      resourceMisuse: "🏢 Misuse of resources",
      discrimination: "🚫 Discrimination/Harassment",
      documentDestruction: "📝 Document destruction",
      lawViolation: "⚖️ Law violations",
      policyViolation: "📋 Policy violations",
      otherUnethical: "⚠️ Other unethical activities",
    },
    specify: "Specify",
  },
  question2: {
    label: "Identify the people involved",
    add: "Add",
    person: "Person",
    fields: {
      firstName: "First name",
      lastName: "Last name",
      relation: "Relationship with the Group",
      specify: "Specify (company / position / other)",
    },
    options: {
      employee: "Employee",
      supplier: "Supplier",
      client: "Client",
      investor: "Investor",
      other: "Other",
    },
  },
  question3: {
    label: "Indicate where the incident occurred",
    fields: {
      country: "Country",
      state: "State / Province",
      city: "City",
      location: "Location",
      specifyLocation: "Specify location",
    },
    options: {
      plantCajamarquilla: "Cajamarquilla Plant",
      officesMiraflores: "Miraflores Offices",
      peripheralWarehouse: "Peripheral Warehouse",
      other: "Other (specify)",
    },
  },
  question4: {
    label: "Indicate the date or period when the incident occurred",
    selectDate: "Select a date",
  },
  question5: {
    label: "Describe all the details that help analyze and evaluate your irregularity",
    placeholder:
      "Include relevant information such as dates, places, people involved, and a detailed description of the facts.",
    characters: "characters",
  },
  question6: {
    label: "Do you have physical or digital evidence that could help in the investigation?",
    options: {
      notPossible: "It is not possible for me to provide any evidence",
      notHave: "I don't have evidence, but I could obtain it",
      bothTypes: "I have physical and digital evidence that I would like to provide",
      physical: "I have physical evidence that I want to provide",
      digital: "I have digital evidence that I want to provide",
    },
    fields: {
      physicalDelivery: "Indicate how you will deliver the physical information",
      digitalFiles: "Select digital evidence (max. 5 files, 20MB)",
      whereToObtain: "Where could the Group obtain evidence?",
      whereElse: "Where else could evidence be obtained?",
    },
    fileAttach: "Files will be attached when submitting the form.",
  },
  question17: {
    label: "Which of the following options best describes your relationship with the Group?",
    options: {
      employee: "Employee",
      supplier: "Supplier",
      client: "Client",
      exEmployee: "Former Employee",
      other: "Other",
    },
    specify: "Specify",
  },
  question18: {
    label: "Do you want to keep your identity anonymous?",
    options: {
      no: "No",
      yes: "Yes",
    },
    emailContact: "Provide an email address to maintain contact",
    emailNote: "This email will be used only for communications related to your report.",
  },
  personalInfo: {
    title: "Optional Contact Information",
    subtitle: "If you have no objection to sharing your identity, please provide the following optional information",
    anonymous: "You have chosen to keep your identity anonymous. You can continue to the next step.",
    fields: {
      fullName: "Enter your full name",
      phone: "Enter a contact phone number",
      email: "Enter a contact email address",
      otherContact: "Indicate any other form of contact",
      position: "Indicate your position in the Group",
      area: "Indicate the area to which you belong",
    },
    areas: {
      hr: "HR",
      finance: "Finance",
      accounting: "Accounting",
      management: "Management",
      other: "Others",
    },
  },
  summary: {
    title: "Report Summary",
    reviewNote:
      "Please review the information before submitting your report. Once submitted, you will receive a tracking code.",
    sections: {
      mainData: "Main Data",
      mainDataDesc: "Basic information about the irregularity",
      contactData: "Contact Data",
      contactDataDesc: "Information to communicate with you",
    },
    fields: {
      irregularityTypes: "Types of irregularity",
      date: "Incident date",
      location: "Location",
      involvedPeople: "People involved",
      details: "Details",
      evidence: "Evidence",
      whereToObtain: "Where to obtain",
      relationWithGroup: "Relationship with the Group",
      anonymousReport: "Anonymous report",
      contactEmail: "Contact email",
      name: "Name",
      phone: "Phone",
      email: "Email",
      position: "Position",
      area: "Area",
    },
    notSpecified: "Not specified",
    terms: {
      authorize: "I authorize Grupo Silvestre to process my personal data",
      agreement: "By submitting this form, I agree that I have read the personal data processing clause.",
    },
    submitNote:
      'Click the "Submit report" button to register your irregularity. You will receive a tracking code for future inquiries.',
  },
  success: {
    title: "Report successfully submitted",
    message: "You will be redirected to the home page in a few seconds...",
    code: "Your report has been registered with the code: GS-",
  },
  errors: {
    incompleteFields: "Please complete all required fields before continuing.",
    termsRequired: "You must accept the terms and conditions to submit the report.",
    submitError: "Error submitting the report",
    tryAgain: "Please try again later.",
  },
}

// Recursos de traducción
const resources = {
  es: {
    translation: translationES,
  },
  en: {
    translation: translationEN,
  },
}

i18n
  // Detecta el idioma del navegador
  .use(LanguageDetector)
  // Pasa el i18n a react-i18next
  .use(initReactI18next)
  // Inicializa i18next
  .init({
    resources,
    fallbackLng: "es",
    interpolation: {
      escapeValue: false, // React ya escapa los valores
    },
    detection: {
      order: ["localStorage", "navigator"],
      caches: ["localStorage"],
    },
  })

export default i18n

