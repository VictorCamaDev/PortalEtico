"use client"

import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Pregunta17 } from "../questions/Pregunta17"
import { Pregunta18 } from "../questions/Pregunta18"
import { useEffect } from "react"

export function FormStep3() {
  const {
    register,
    watch,
    formState: { errors },
  } = useFormContext<FormData>()

  const anonimo = watch("anonimo")

  // Efecto para mostrar/ocultar campos de información personal
  useEffect(() => {
    if (anonimo === "no") {
      // Mostrar sección de información personal
      const elements = document.querySelectorAll('[id^="anonimato"]')
      elements.forEach((el) => {
        ;(el as HTMLElement).style.display = "block"
      })
    } else {
      // Ocultar sección de información personal
      const elements = document.querySelectorAll('[id^="anonimato"]')
      elements.forEach((el) => {
        ;(el as HTMLElement).style.display = "none"
      })
    }
  }, [anonimo])

  // Registrar los campos manualmente
  useEffect(() => {
    register("relacionGrupo", { required: "Debe indicar su relación con el Grupo" })
    register("anonimo", { required: "Debe indicar si desea mantener su identidad en el anonimato" })
  }, [register])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-primary mb-4">Opciones de Contacto</h2>

        <div className="space-y-6">
          {/* Usar los componentes de preguntas individuales */}
          <Pregunta17 />
          <Pregunta18 />
          {/* Eliminamos Pregunta19 ya que ahora está integrada en Pregunta18 */}
        </div>
      </div>
    </div>
  )
}

