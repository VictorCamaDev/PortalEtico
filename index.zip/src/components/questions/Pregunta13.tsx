"use client"

import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { UserCheck, UserX } from "lucide-react"

export function Pregunta13() {
  const { setValue, watch } = useFormContext<FormData>()
  const conocimientoPrevio = watch("conocimientoPrevio") || ""
  const quienesConocen = watch("quienesConocen") || ""
  const comoConocen = watch("comoConocen") || ""

  return (
    <div className="space-y-4 pt-4 border-t">
      <div>
        <Label className="text-base font-medium">
          ¿Alguna dirección, gerencia, subgerencia o jefatura conoce de estos hechos?
        </Label>
        <p className="text-sm text-muted-foreground mt-1">
          Indique si alguien en un cargo de responsabilidad tiene conocimiento previo sobre esta irregularidad.
        </p>
      </div>

      <RadioGroup
        onValueChange={(value) => setValue("conocimientoPrevio", value)}
        value={conocimientoPrevio}
        className="flex gap-6"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="no" id="conocimiento_no" />
          <Label htmlFor="conocimiento_no" className="font-normal flex items-center gap-2">
            No
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="si" id="conocimiento_si" />
          <Label htmlFor="conocimiento_si" className="font-normal flex items-center gap-2">
            Sí
          </Label>
        </div>
      </RadioGroup>

      {conocimientoPrevio === "si" && (
        <div className="ml-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="quienesConocen">¿Quiénes?</Label>
            <Input
              id="quienesConocen"
              value={quienesConocen}
              onChange={(e) => setValue("quienesConocen", e.target.value)}
              placeholder="Ingrese nombres o áreas responsables"
              className="max-w-md"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="comoConocen">¿Cómo?</Label>
            <Input
              id="comoConocen"
              value={comoConocen}
              onChange={(e) => setValue("comoConocen", e.target.value)}
              placeholder="Explique cómo se enteraron"
              className="max-w-md"
            />
          </div>
        </div>
      )}
    </div>
  )
}

