"use client"

import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Eye, EyeOff } from "lucide-react"

export function Pregunta12() {
  const { setValue, watch } = useFormContext<FormData>()
  const ocultado = watch("ocultado") || ""
  const comoOcultado = watch("comoOcultado") || ""
  const quienesOcultan = watch("quienesOcultan") || ""

  return (
    <div className="space-y-4 pt-4 border-t">
      <Label className="text-base font-medium">
        ¿Cree usted que estos hechos están siendo ocultados de alguna manera?
      </Label>

      <RadioGroup onValueChange={(value) => setValue("ocultado", value)} value={ocultado} className="flex gap-6">
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="no" id="ocultado_no" />
          <Label htmlFor="ocultado_no" className="font-normal flex items-center gap-2">
            No
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="si" id="ocultado_si" />
          <Label htmlFor="ocultado_si" className="font-normal flex items-center gap-2">
            Sí
          </Label>
        </div>
      </RadioGroup>

      {ocultado === "si" && (
        <div className="ml-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="comoOcultado">¿Cómo?</Label>
            <Input
              id="comoOcultado"
              value={comoOcultado}
              onChange={(e) => setValue("comoOcultado", e.target.value)}
              placeholder="Describa cómo se está ocultando"
              className="max-w-md"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="quienesOcultan">¿Por quiénes?</Label>
            <Input
              id="quienesOcultan"
              value={quienesOcultan}
              onChange={(e) => setValue("quienesOcultan", e.target.value)}
              placeholder="Ingrese nombres o detalles"
              className="max-w-md"
            />
          </div>
        </div>
      )}
    </div>
  )
}

