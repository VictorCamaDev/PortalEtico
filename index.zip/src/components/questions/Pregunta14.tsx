"use client"

import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Briefcase, HeartHandshake, UserPlus, HelpCircle } from "lucide-react"

export function Pregunta14() {
  const { setValue, watch } = useFormContext<FormData>()
  const relacion = watch("relacion") || ""
  const relacionOtro = watch("relacionOtro") || ""

  return (
    <div className="space-y-4 pt-4 border-t">
      <Label className="text-base font-medium">¿Qué tipo de relación existe entre las personas involucradas?</Label>

      <RadioGroup onValueChange={(value) => setValue("relacion", value)} value={relacion} className="space-y-3">
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="Familiar" id="relacion_familiar" />
          <Label htmlFor="relacion_familiar" className="font-normal flex items-center gap-2">
            Familiar
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="Laboral" id="relacion_laboral" />
          <Label htmlFor="relacion_laboral" className="font-normal flex items-center gap-2">
            Laboral
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="Amical" id="relacion_amical" />
          <Label htmlFor="relacion_amical" className="font-normal flex items-center gap-2">
            Amical
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="Otro" id="relacion_otro" />
          <Label htmlFor="relacion_otro" className="font-normal flex items-center gap-2">
            Otro
          </Label>
        </div>
      </RadioGroup>

      {relacion === "Otro" && (
        <div className="ml-6 space-y-2">
          <Label htmlFor="relacionOtro">¿Cuál?</Label>
          <Input
            id="relacionOtro"
            value={relacionOtro}
            onChange={(e) => setValue("relacionOtro", e.target.value)}
            placeholder="Especifica la relación"
            className="max-w-md"
          />
        </div>
      )}
    </div>
  )
}

