"use client"

import { useEffect } from "react"
import type { IProps3 } from "../../interfaces/ICuestionario"
import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function Pregunta3({ onChange }: IProps3) {
  const { setValue, watch, register } = useFormContext<FormData>()
  const ubicacion = watch("ubicacion") || { pais: "", provincia: "", ciudad: "", sede: "" }
  const sedeOtro = watch("ubicacion.sedeOtro") || ""

  // Registrar campos como requeridos
  useEffect(() => {
    register("ubicacion.pais", { required: "El país es requerido" })
    register("ubicacion.provincia", { required: "La provincia es requerida" })
    register("ubicacion.ciudad", { required: "La ciudad es requerida" })
    register("ubicacion.sede", { required: "La sede es requerida" })
  }, [register])

  // Mantener la compatibilidad con el componente original
  useEffect(() => {
    if (onChange) {
      onChange(ubicacion)
    }
  }, [ubicacion, onChange])

  const handleChange = (field: string, value: string) => {
    setValue("ubicacion", { ...ubicacion, [field]: value })
  }

  return (
    <div>
      <Label className="text-base font-medium">
        Indique en qué lugar sucedió el incidente <span className="text-destructive">*</span>
      </Label>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
        <div>
          <Label htmlFor="ubicacion.pais">
            País <span className="text-destructive">*</span>
          </Label>
          <Input
            id="ubicacion.pais"
            value={ubicacion.pais}
            onChange={(e) => handleChange("pais", e.target.value)}
            className="mt-1"
            required
          />
        </div>
        <div>
          <Label htmlFor="ubicacion.provincia">
            Estado / Provincia <span className="text-destructive">*</span>
          </Label>
          <Input
            id="ubicacion.provincia"
            value={ubicacion.provincia}
            onChange={(e) => handleChange("provincia", e.target.value)}
            className="mt-1"
            required
          />
        </div>
        <div>
          <Label htmlFor="ubicacion.ciudad">
            Ciudad <span className="text-destructive">*</span>
          </Label>
          <Input
            id="ubicacion.ciudad"
            value={ubicacion.ciudad}
            onChange={(e) => handleChange("ciudad", e.target.value)}
            className="mt-1"
            required
          />
        </div>
        <div>
          <Label htmlFor="ubicacion.sede">
            Sede <span className="text-destructive">*</span>
          </Label>
          <Select onValueChange={(value) => handleChange("sede", value)} value={ubicacion.sede} required>
            <SelectTrigger className="w-full mt-1">
              <SelectValue placeholder="Seleccione" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="PlantaCajamarquilla">Planta Cajamarquilla</SelectItem>
              <SelectItem value="OficinasMiraflores">Oficinas Miraflores</SelectItem>
              <SelectItem value="AlmacenPeriferico">Almacén periférico</SelectItem>
              <SelectItem value="Otro">Otro (especificar)</SelectItem>
            </SelectContent>
          </Select>

          {ubicacion.sede === "Otro" && (
            <div className="mt-2">
              <Label htmlFor="ubicacion.sedeOtro">
                Especificar sede <span className="text-destructive">*</span>
              </Label>
              <Input
                id="ubicacion.sedeOtro"
                value={sedeOtro}
                onChange={(e) => setValue("ubicacion.sedeOtro", e.target.value)}
                className="mt-1"
                required={ubicacion.sede === "Otro"}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

