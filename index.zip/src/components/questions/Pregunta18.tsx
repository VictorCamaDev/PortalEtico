"use client"

import { useEffect } from "react"
import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { UserRound, UserX2, Mail } from "lucide-react"

export function Pregunta18() {
  const { setValue, watch, register } = useFormContext<FormData>()
  const anonimo = watch("anonimo") || ""
  const correoContacto = watch("correoContacto") || ""

  // Registrar el campo como requerido
  useEffect(() => {
    register("anonimo", { required: "Debe indicar si desea mantener su identidad en el anonimato" })
  }, [register])

  return (
    <div className="space-y-4 pt-4 border-t">
      <Label className="text-base font-medium">
        ¿Desea mantener su identidad en el anonimato? <span className="text-destructive">*</span>
      </Label>

      <RadioGroup onValueChange={(value) => setValue("anonimo", value)} value={anonimo} className="flex gap-6">
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="no" id="anonimo_no" />
          <Label htmlFor="anonimo_no" className="font-normal flex items-center gap-2">
            <UserRound className="h-4 w-4 text-primary" /> No
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="si" id="anonimo_si" />
          <Label htmlFor="anonimo_si" className="font-normal flex items-center gap-2">
            <UserX2 className="h-4 w-4 text-gray-600" /> Sí
          </Label>
        </div>
      </RadioGroup>

      {anonimo === "si" && (
        <div className="ml-6 space-y-2 pt-4">
          <Label htmlFor="correoContacto" className="text-base font-medium flex items-center gap-2">
            <Mail className="h-4 w-4 text-blue-600" />
            Proporcione una cuenta de correo electrónico para mantener contacto
          </Label>
          <Input
            id="correoContacto"
            type="email"
            value={correoContacto}
            onChange={(e) => setValue("correoContacto", e.target.value)}
            placeholder="ejemplo@correo.com"
            className="max-w-md"
          />
          <p className="text-sm text-muted-foreground">
            Este correo se utilizará únicamente para comunicaciones relacionadas con su reporte.
          </p>
        </div>
      )}
    </div>
  )
}

