"use client"

import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { User, Eye, Users, Ear, MoreHorizontal } from "lucide-react"

export function Pregunta10() {
  const { setValue, watch } = useFormContext<FormData>()
  const conocimiento = watch("conocimiento") || ""
  const conocimientoOtro = watch("conocimientoOtro") || ""

  return (
    <div className="space-y-4">
      <Label className="text-base font-medium">¿Cómo tomó conocimiento de estos hechos?</Label>

      <RadioGroup onValueChange={(value) => setValue("conocimiento", value)} value={conocimiento} className="space-y-3">
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="me_sucedio" id="me_sucedio" />
          <Label htmlFor="me_sucedio" className="font-normal flex items-center gap-2">
            Me sucedió a mí
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="fui_testigo" id="fui_testigo" />
          <Label htmlFor="fui_testigo" className="font-normal flex items-center gap-2">
             Fui testigo
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="compañero" id="compañero" />
          <Label htmlFor="compañero" className="font-normal flex items-center gap-2">
             Un compañero de trabajo me comentó la situación
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="escuche" id="escuche" />
          <Label htmlFor="escuche" className="font-normal flex items-center gap-2">
             Lo escuché de casualidad
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="otro" id="otro" />
          <Label htmlFor="otro" className="font-normal flex items-center gap-2">
             Otros
          </Label>
        </div>
      </RadioGroup>

      {conocimiento === "otro" && (
        <div className="ml-6 space-y-2">
          <Label htmlFor="conocimientoOtro">Especificar</Label>
          <Input
            id="conocimientoOtro"
            value={conocimientoOtro}
            onChange={(e) => setValue("conocimientoOtro", e.target.value)}
            placeholder="Escriba aquí..."
            className="max-w-md"
          />
        </div>
      )}
    </div>
  )
}

