"use client"

import { useEffect } from "react"
import type { IProps4 } from "../../interfaces/ICuestionario"
import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { CalendarIcon } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { FormField, FormItem, FormControl } from "@/components/ui/form"

export function Pregunta4({ onChange }: IProps4) {
  const { control, watch, setValue } = useFormContext<FormData>()
  const fecha = watch("fecha") || ""

  // Mantener la compatibilidad con el componente original
  useEffect(() => {
    if (onChange) {
      onChange({ fecha })
    }
  }, [fecha, onChange])

  return (
    <div>
      <Label className="text-base font-medium">Indique la fecha o período en el cual sucedió el incidente</Label>
      <div className="mt-2">
        <FormField
          control={control}
          name="fecha"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}
                    >
                      {field.value ? (
                        format(new Date(field.value), "PPP", { locale: es })
                      ) : (
                        <span>Seleccione una fecha</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value ? new Date(field.value) : undefined}
                    onSelect={(date) => field.onChange(date ? date.toISOString() : "")}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </FormItem>
          )}
        />
      </div>
    </div>
  )
}

