"use client"

import { useEffect } from "react"
import type { IProps2 } from "../../interfaces/ICuestionario"
import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2 } from "lucide-react"

export function Pregunta2({ onChange }: IProps2) {
  const { setValue, watch } = useFormContext<FormData>()
  const involucrados = watch("involucrados") || [{ id: 1, nombre: "", apellido: "", relacion: "", otro: "" }]

  // Mantener la compatibilidad con el componente original
  useEffect(() => {
    if (onChange) {
      onChange(involucrados)
    }
  }, [involucrados, onChange])

  const agregarInvolucrado = () => {
    setValue("involucrados", [
      ...involucrados,
      { id: involucrados.length + 1, nombre: "", apellido: "", relacion: "", otro: "" },
    ])
  }

  const eliminarInvolucrado = (id: number) => {
    if (involucrados.length > 1) {
      setValue(
        "involucrados",
        involucrados.filter((inv) => inv.id !== id),
      )
    }
  }

  const handleInvolucradoChange = (id: number, field: string, value: string) => {
    setValue(
      "involucrados",
      involucrados.map((inv) => (inv.id === id ? { ...inv, [field]: value } : inv)),
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Label className="text-base font-medium">Identifique a las personas involucradas</Label>
        <Button type="button" onClick={agregarInvolucrado} variant="outline" size="sm" className="text-primary">
          <Plus className="h-4 w-4 mr-1" /> Agregar
        </Button>
      </div>

      {involucrados.map((inv, index) => (
        <div key={inv.id} className="p-4 border rounded-lg bg-card">
          <div className="flex justify-between items-center mb-3">
            <h4 className="font-medium">Involucrado #{index + 1}</h4>
            {involucrados.length > 1 && (
              <Button
                type="button"
                onClick={() => eliminarInvolucrado(inv.id)}
                variant="ghost"
                size="sm"
                className="text-destructive h-8 w-8 p-0"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor={`involucrados.${index}.nombre`}>Nombres</Label>
              <Input
                id={`involucrados.${index}.nombre`}
                value={inv.nombre}
                onChange={(e) => handleInvolucradoChange(inv.id, "nombre", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor={`involucrados.${index}.apellido`}>Apellidos</Label>
              <Input
                id={`involucrados.${index}.apellido`}
                value={inv.apellido}
                onChange={(e) => handleInvolucradoChange(inv.id, "apellido", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor={`involucrados.${index}.relacion`}>Relación con el Grupo</Label>
              <Select
                onValueChange={(value) => handleInvolucradoChange(inv.id, "relacion", value)}
                value={inv.relacion}
              >
                <SelectTrigger className="w-full mt-1">
                  <SelectValue placeholder="Seleccione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Empleado">Empleado</SelectItem>
                  <SelectItem value="Proveedor">Proveedor</SelectItem>
                  <SelectItem value="Cliente">Cliente</SelectItem>
                  <SelectItem value="Inversionista">Inversionista</SelectItem>
                  <SelectItem value="Otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor={`involucrados.${index}.otro`}>Especificar (empresa / cargo / otro)</Label>
              <Input
                id={`involucrados.${index}.otro`}
                value={inv.otro}
                onChange={(e) => handleInvolucradoChange(inv.id, "otro", e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

