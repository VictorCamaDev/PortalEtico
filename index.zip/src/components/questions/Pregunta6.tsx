"use client"

import type React from "react"

import { useState } from "react"
import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Button } from "@/components/ui/button"
import { FileUp } from "lucide-react"

export function Pregunta6() {
  const { setValue, watch } = useFormContext<FormData>()
  const evidenciaTipo = watch("evidencia.tipo") || ""
  const [archivos, setArchivos] = useState<File[]>([])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && archivos.length < 5) {
      const newFiles = [...archivos, e.target.files[0]]
      setArchivos(newFiles)
      setValue("evidencia.archivos", newFiles)
    }
  }

  return (
    <div className="space-y-4">
      <Label className="text-base font-medium">
        ¿Posee usted evidencia física o digital que pueda ayudar en la investigación?
      </Label>

      <RadioGroup
        onValueChange={(value) => setValue("evidencia.tipo", value)}
        value={evidenciaTipo}
        className="space-y-3"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="no_posible" id="no_posible" />
          <Label htmlFor="no_posible" className="font-normal">
            No me es posible proporcionar evidencias de ningún tipo
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="no_tengo" id="no_tengo" />
          <Label htmlFor="no_tengo" className="font-normal">
            No tengo evidencias, pero podría obtenerlas
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="fisica_digital" id="fisica_digital" />
          <Label htmlFor="fisica_digital" className="font-normal">
            Tengo evidencia física y digital que me gustaría entregar
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="fisica" id="fisica" />
          <Label htmlFor="fisica" className="font-normal">
            Tengo evidencia física que deseo entregar
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="digital" id="digital" />
          <Label htmlFor="digital" className="font-normal">
            Tengo evidencia digital que deseo entregar
          </Label>
        </div>
      </RadioGroup>

      {/* Campos condicionales según el tipo de evidencia */}
      {evidenciaTipo === "fisica" && (
        <div className="ml-6 space-y-2">
          <Label htmlFor="evidencia.entregaFisica">Indique la forma en la que entregará la información física</Label>
          <Input
            id="evidencia.entregaFisica"
            value={watch("evidencia.entregaFisica") || ""}
            onChange={(e) => setValue("evidencia.entregaFisica", e.target.value)}
          />
        </div>
      )}

      {evidenciaTipo === "digital" && (
        <div className="ml-6 space-y-2">
          <Label htmlFor="evidencia.archivos">Seleccione evidencias digitales (máx. 5 archivos, 20MB)</Label>
          <div className="flex items-center gap-2">
            <Input id="evidencia.archivos" type="file" className="cursor-pointer" onChange={handleFileChange} />
            <Button type="button" variant="outline" size="icon">
              <FileUp className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">Los archivos se adjuntarán al enviar el formulario.</p>
        </div>
      )}

      {["no_posible", "no_tengo", "fisica", "digital", "fisica_digital"].includes(evidenciaTipo) && (
        <div className="ml-6 space-y-2">
          <Label htmlFor="evidencia.dondeObtener">
            {evidenciaTipo === "no_posible" || evidenciaTipo === "no_tengo"
              ? "¿Dónde el Grupo podría obtener evidencia?"
              : "¿Dónde más se podría obtener evidencia?"}
          </Label>
          <Textarea
            id="evidencia.dondeObtener"
            value={watch("evidencia.dondeObtener") || ""}
            onChange={(e) => setValue("evidencia.dondeObtener", e.target.value)}
            className="min-h-[100px]"
            placeholder="Indique lugares, personas o documentos donde se podría encontrar más evidencia"
          />
        </div>
      )}
    </div>
  )
}

