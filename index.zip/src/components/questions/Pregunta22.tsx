"use client"

import { useFormContext } from "react-hook-form"
import type { FormData } from "../EthicsReportForm"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Mail } from "lucide-react"

export function Pregunta22() {
  const { setValue, watch } = useFormContext<FormData>()
  const correo = watch("correo") || ""

  return (
    <div className="space-y-2 pt-4 border-t">
      <Label htmlFor="correo" className="text-base font-medium flex items-center gap-2">
        <Mail className="h-4 w-4 text-blue-600" />
        Indique un correo electrónico de contacto
      </Label>
      <Input
        id="correo"
        type="email"
        value={correo}
        onChange={(e) => setValue("correo", e.target.value)}
        placeholder="ejemplo@correo.com"
        className="max-w-md"
      />
    </div>
  )
}

